// 3_����1
#include <iostream>


void db_backup()
{
}

void db_remove() {}

int main()
{
	db_backup();
	db_remove();
}
