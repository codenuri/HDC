#include <iostream>

class vector
{
private:
	int* ptr;
	int  sz;

public:
	vector(int size)
	{
		sz = size;
		ptr = new int[size];
	}
	~vector()
	{
		delete[] ptr;
	}
};

int main()
{
	vector v1(4);
	vector v2 = v1;


}