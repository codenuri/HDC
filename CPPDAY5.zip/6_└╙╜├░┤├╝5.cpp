#include <iostream>

class Counter
{
	int count = 0;
public:
	void increment()
	{
		++count;
	}
	int get_count() const { return count; }
};
int main()
{
	Counter c;
	c.increment();
	c.increment();
	c.increment();

	std::cout << c.get_count() << std::endl;
}