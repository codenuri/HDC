﻿// 5_상속2

class Base
{
private:   int a;	
protected: int b;	
public:    int c;	
};
class Derived : public Base  
{
public:
	void foo()
	{
		a = 0;	
		b = 0;  
		c = 0;  
	}
};
int main()
{
	Base base;
	base.a = 0; 
	base.b = 0; 
	base.c = 0; 
}
