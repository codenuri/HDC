#include <iostream>

class Car
{
	int color;
	int speed;

	static int cnt; 

public:
	Car() { ++cnt; }
	~Car() { --cnt; }
	
	void go() { std::cout << "Car go" << std::endl; }

	static int get_count() { return cnt; }
};
int Car::cnt = 0; 


int main()
{
	std::cout << Car::get_count() << std::endl; // 0

	Car c1;
	Car c2;

	std::cout << Car::get_count() << std::endl; // 2

}
